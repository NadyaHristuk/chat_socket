import React, { Component } from 'react';
import { Container, MessageHeader, Segment, Comment, Input, Button, Header, Icon} from 'semantic-ui-react';
import moment from 'moment';

class Chat extends Component {
    state = {
        input:'',
        messages:[],
    }

    handlerChange=(e)=>{
      this.setState({
          input:e.target.value
      })
    }

    recMessage=()=>{
        let content = {
            time: moment().format('LTS'),
            message:this.state.input,
        }
        this.setState(prev =>({
            messages:[...prev.messages,content]
        }))
}


  render() {
      const {input , messages}= this.state;
    return (
      <div className='container'>
        <Container fluid>

        <MessageHeader/>
           <Segment>

           <Segment clearing>
                <Header 
                fluid='true'
                as='h2'
                floated='left'
                style={{
                    marginBottom: 0
                }}>
                <Header.Subheader>
                    Our Chat / Online Users
                </Header.Subheader>
                </Header>
            </Segment>

             <Comment.Group className='messages'>
             {messages.map( el =>
                 <Comment>
                 <Comment.Avatar/>
                 <Comment.Content>
                     <Comment.Author as='a'>
                         author
                     </Comment.Author>
                     <Comment.Metadata>
                        {el.time}
                     </Comment.Metadata>

                  <Comment.Text>{el.message}</Comment.Text>
                 </Comment.Content>
             </Comment>)}

             </Comment.Group>
           </Segment>


           <Segment className='message__form'>
                <Input
                    fluid
                    name='message'
                    style={{
                        marginBottom: '.7rem'
                    }}
                    label={<Button icon='add'/>}
                    labelPosition='left'
                    placeholder='Write your message'
                    onChange={this.handlerChange}
                    value={this.state.input}
                   />
                <Button.Group icon widths='2'>
                    <Button color='orange' content='Add Reply' labelPosition='left' icon='edit' onClick={this.recMessage} />
                    {/* <Button color='teal' content='Upload media' labelPosition='right' icon='cloud upload' onClick={this.toggleModal}/> */}
                </Button.Group>
            </Segment>



        </Container>
      </div>
    )
  }
}

export default Chat
